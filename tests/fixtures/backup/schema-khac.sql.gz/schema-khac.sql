--
-- PostgreSQL database dump
--

\restrict gUmLg4Q8XlKbP7TZtprot96hLnOgKLwRzcYuzNd9yCcroK8u6oQlJC4fsjum1Yu

-- Dumped from database version 15.19 (Homebrew)
-- Dumped by pg_dump version 15.19 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: khac; Type: SCHEMA; Schema: -; Owner: hogikids
--

CREATE SCHEMA khac;


ALTER SCHEMA khac OWNER TO hogikids;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: GhiChu; Type: TABLE; Schema: khac; Owner: hogikids
--

CREATE TABLE khac."GhiChu" (
    id integer NOT NULL,
    "noiDung" text NOT NULL
);


ALTER TABLE khac."GhiChu" OWNER TO hogikids;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: khac; Owner: hogikids
--

CREATE TABLE khac._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE khac._prisma_migrations OWNER TO hogikids;

--
-- Data for Name: GhiChu; Type: TABLE DATA; Schema: khac; Owner: hogikids
--

COPY khac."GhiChu" (id, "noiDung") FROM stdin;
1	FX-khong-phai-backup-cua-app
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: khac; Owner: hogikids
--

COPY khac._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
FX-mig-khac	ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff	2026-10-01 00:00:01+07	20260930170000_tai_khoan_phu_phan_quyen	\N	\N	2026-10-01 00:00:00+07	1
\.


--
-- Name: GhiChu GhiChu_pkey; Type: CONSTRAINT; Schema: khac; Owner: hogikids
--

ALTER TABLE ONLY khac."GhiChu"
    ADD CONSTRAINT "GhiChu_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: khac; Owner: hogikids
--

ALTER TABLE ONLY khac._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict gUmLg4Q8XlKbP7TZtprot96hLnOgKLwRzcYuzNd9yCcroK8u6oQlJC4fsjum1Yu

