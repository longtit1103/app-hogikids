--
-- PostgreSQL database dump
--

\restrict osdljGflvzfZZ7mdHSS4cXQTGrHw0PtFeP8d4stQiNYNNObMSxHpS0Jf1d1daee

-- Dumped from database version 15.19 (Homebrew)
-- Dumped by pg_dump version 15.19 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: app; Type: SCHEMA; Schema: -; Owner: hogikids
--

CREATE SCHEMA app;


ALTER SCHEMA app OWNER TO hogikids;

--
-- Name: CashMovementKind; Type: TYPE; Schema: app; Owner: hogikids
--

CREATE TYPE app."CashMovementKind" AS ENUM (
    'LOAN_IN',
    'CAPITAL_IN',
    'DIRECT_SALE',
    'OTHER_IN',
    'LOAN_REPAY',
    'CAPITAL_OUT',
    'DEPOSIT_OUT',
    'DEPOSIT_IN',
    'SAVINGS_OUT',
    'SAVINGS_IN'
);


ALTER TYPE app."CashMovementKind" OWNER TO hogikids;

--
-- Name: ExpenseSource; Type: TYPE; Schema: app; Owner: hogikids
--

CREATE TYPE app."ExpenseSource" AS ENUM (
    'MANUAL',
    'RECURRING',
    'IMPORT',
    'ADS_API'
);


ALTER TYPE app."ExpenseSource" OWNER TO hogikids;

--
-- Name: LoanKind; Type: TYPE; Schema: app; Owner: hogikids
--

CREATE TYPE app."LoanKind" AS ENUM (
    'TERM',
    'OVERDRAFT',
    'BULLET'
);


ALTER TYPE app."LoanKind" OWNER TO hogikids;

--
-- Name: OrderStatus; Type: TYPE; Schema: app; Owner: hogikids
--

CREATE TYPE app."OrderStatus" AS ENUM (
    'PENDING',
    'SHIPPING',
    'COMPLETED',
    'RETURNED',
    'CANCELLED'
);


ALTER TYPE app."OrderStatus" OWNER TO hogikids;

--
-- Name: ProductStatus; Type: TYPE; Schema: app; Owner: hogikids
--

CREATE TYPE app."ProductStatus" AS ENUM (
    'ACTIVE',
    'HIDDEN'
);


ALTER TYPE app."ProductStatus" OWNER TO hogikids;

--
-- Name: SyncKind; Type: TYPE; Schema: app; Owner: hogikids
--

CREATE TYPE app."SyncKind" AS ENUM (
    'PANCAKE',
    'META_ADS',
    'TIKTOK_ADS',
    'BACKUP',
    'TIKTOK_SHOP',
    'TIKTOK_SHOP_ANALYTICS'
);


ALTER TYPE app."SyncKind" OWNER TO hogikids;

--
-- Name: SyncStatus; Type: TYPE; Schema: app; Owner: hogikids
--

CREATE TYPE app."SyncStatus" AS ENUM (
    'RUNNING',
    'OK',
    'ERROR'
);


ALTER TYPE app."SyncStatus" OWNER TO hogikids;

--
-- Name: ThuNhapKind; Type: TYPE; Schema: app; Owner: hogikids
--

CREATE TYPE app."ThuNhapKind" AS ENUM (
    'LAI_TIET_KIEM'
);


ALTER TYPE app."ThuNhapKind" OWNER TO hogikids;

--
-- Name: set_setting_updated_at(); Type: FUNCTION; Schema: app; Owner: hogikids
--

CREATE FUNCTION app.set_setting_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."updatedAt" = now() AT TIME ZONE 'utc';
  RETURN NEW;
END;
$$;


ALTER FUNCTION app.set_setting_updated_at() OWNER TO hogikids;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: BanGhiDaXoa; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."BanGhiDaXoa" (
    id text NOT NULL,
    bang text NOT NULL,
    "banGhiId" text NOT NULL,
    nhan text NOT NULL,
    "soTien" integer NOT NULL,
    ngay timestamp(3) without time zone NOT NULL,
    anh jsonb NOT NULL,
    "xoaLuc" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "khoiPhucLuc" timestamp(3) without time zone
);


ALTER TABLE app."BanGhiDaXoa" OWNER TO hogikids;

--
-- Name: CashMovement; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."CashMovement" (
    id text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    kind app."CashMovementKind" NOT NULL,
    amount integer NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "loanId" text,
    "savingsId" text,
    CONSTRAINT "CashMovement_amount_duong" CHECK ((amount > 0)),
    CONSTRAINT "CashMovement_loan_bat_buoc" CHECK (((kind <> ALL (ARRAY['LOAN_IN'::app."CashMovementKind", 'LOAN_REPAY'::app."CashMovementKind", 'DEPOSIT_OUT'::app."CashMovementKind", 'DEPOSIT_IN'::app."CashMovementKind"])) OR ("loanId" IS NOT NULL))),
    CONSTRAINT "CashMovement_loan_savings_loai_tru" CHECK ((("loanId" IS NULL) OR ("savingsId" IS NULL))),
    CONSTRAINT "CashMovement_savings_bat_buoc" CHECK (((kind <> ALL (ARRAY['SAVINGS_OUT'::app."CashMovementKind", 'SAVINGS_IN'::app."CashMovementKind"])) OR ("savingsId" IS NOT NULL))),
    CONSTRAINT "CashMovement_savings_dung_cho" CHECK ((("savingsId" IS NULL) OR (kind = ANY (ARRAY['SAVINGS_OUT'::app."CashMovementKind", 'SAVINGS_IN'::app."CashMovementKind"]))))
);


ALTER TABLE app."CashMovement" OWNER TO hogikids;

--
-- Name: Channel; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."Channel" (
    id text NOT NULL,
    name text NOT NULL,
    color text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "platformFeePct" double precision DEFAULT 0 NOT NULL,
    "paymentFeePct" double precision DEFAULT 0 NOT NULL,
    "sortOrder" integer NOT NULL
);


ALTER TABLE app."Channel" OWNER TO hogikids;

--
-- Name: Expense; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."Expense" (
    id text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "categoryId" text NOT NULL,
    "adsSource" text,
    description text NOT NULL,
    "channelId" text,
    amount integer NOT NULL,
    source app."ExpenseSource" DEFAULT 'MANUAL'::app."ExpenseSource" NOT NULL,
    "refId" text,
    "recurringId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "recurringMonth" text,
    CONSTRAINT "Expense_recurringMonth_chi_cho_dinh_ky" CHECK ((("recurringId" IS NULL) = ("recurringMonth" IS NULL))),
    CONSTRAINT "Expense_recurringMonth_khop_ngay" CHECK ((("recurringMonth" IS NULL) OR ("recurringMonth" = to_char(((date AT TIME ZONE 'UTC'::text) AT TIME ZONE 'Asia/Ho_Chi_Minh'::text), 'YYYY-MM'::text))))
);


ALTER TABLE app."Expense" OWNER TO hogikids;

--
-- Name: ExpenseCategory; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."ExpenseCategory" (
    id text NOT NULL,
    name text NOT NULL,
    "isSystem" boolean DEFAULT false NOT NULL,
    "isHidden" boolean DEFAULT false NOT NULL
);


ALTER TABLE app."ExpenseCategory" OWNER TO hogikids;

--
-- Name: Loan; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."Loan" (
    id text NOT NULL,
    name text NOT NULL,
    lender text DEFAULT ''::text NOT NULL,
    "duNoMoSo" integer DEFAULT 0 NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "annualRateBp" integer DEFAULT 0 NOT NULL,
    "termMonths" integer,
    "firstDueDate" timestamp(3) without time zone,
    "lastDueHandled" timestamp(3) without time zone,
    "closedAt" timestamp(3) without time zone,
    note text DEFAULT ''::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    kind app."LoanKind" DEFAULT 'TERM'::app."LoanKind" NOT NULL,
    "laiCoDinhMoiKy" integer,
    "tienGuiBatBuocMoiKy" integer DEFAULT 0 NOT NULL,
    CONSTRAINT "Loan_annualRateBp_khong_am" CHECK (("annualRateBp" >= 0)),
    CONSTRAINT "Loan_duNoMoSo_khong_am" CHECK (("duNoMoSo" >= 0)),
    CONSTRAINT "Loan_laiCoDinhMoiKy_khong_am" CHECK ((("laiCoDinhMoiKy" IS NULL) OR ("laiCoDinhMoiKy" >= 0))),
    CONSTRAINT "Loan_lich_theo_loai" CHECK ((((kind = 'TERM'::app."LoanKind") AND (("termMonths" IS NULL) = ("firstDueDate" IS NULL))) OR ((kind = 'OVERDRAFT'::app."LoanKind") AND ("termMonths" IS NULL)) OR ((kind = 'BULLET'::app."LoanKind") AND ("termMonths" IS NOT NULL) AND ("firstDueDate" IS NOT NULL)))),
    CONSTRAINT "Loan_termMonths_duong" CHECK ((("termMonths" IS NULL) OR ("termMonths" >= 1))),
    CONSTRAINT "Loan_tienGuiBatBuocMoiKy_khong_am" CHECK (("tienGuiBatBuocMoiKy" >= 0))
);


ALTER TABLE app."Loan" OWNER TO hogikids;

--
-- Name: N8nWorkflowBackup; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."N8nWorkflowBackup" (
    id text NOT NULL,
    name text NOT NULL,
    payload text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE app."N8nWorkflowBackup" OWNER TO hogikids;

--
-- Name: Order; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."Order" (
    id text NOT NULL,
    "pancakeId" text NOT NULL,
    code text NOT NULL,
    "channelId" text NOT NULL,
    status app."OrderStatus" NOT NULL,
    "orderedAt" timestamp(3) without time zone NOT NULL,
    "customerName" text,
    "itemsTotal" integer DEFAULT 0 NOT NULL,
    "shipFeeCustomer" integer DEFAULT 0 NOT NULL,
    discount integer DEFAULT 0 NOT NULL,
    "platformFeeEst" integer DEFAULT 0 NOT NULL,
    "syncedAt" timestamp(3) without time zone NOT NULL,
    raw jsonb,
    "returnedFee" integer DEFAULT 0 NOT NULL,
    "statusChangedAt" timestamp(3) without time zone,
    "rawFetchedAt" timestamp(3) without time zone,
    "backfilledFromMirror" boolean DEFAULT false NOT NULL,
    "paidAtShop" integer DEFAULT 0 NOT NULL
);


ALTER TABLE app."Order" OWNER TO hogikids;

--
-- Name: OrderItem; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."OrderItem" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "variantId" text,
    sku text NOT NULL,
    "productName" text NOT NULL,
    quantity integer NOT NULL,
    "unitPrice" integer NOT NULL,
    "lineDiscount" integer DEFAULT 0 NOT NULL
);


ALTER TABLE app."OrderItem" OWNER TO hogikids;

--
-- Name: Product; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."Product" (
    id text NOT NULL,
    "pancakeId" text NOT NULL,
    name text NOT NULL,
    code text,
    "categoryName" text,
    "imageUrl" text,
    status app."ProductStatus" DEFAULT 'ACTIVE'::app."ProductStatus" NOT NULL,
    "syncedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE app."Product" OWNER TO hogikids;

--
-- Name: RawMetaAdsReport; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawMetaAdsReport" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawMetaAdsReport" OWNER TO hogikids;

--
-- Name: RawPancakeCustomer; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawPancakeCustomer" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawPancakeCustomer" OWNER TO hogikids;

--
-- Name: RawPancakeInventoryHistory; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawPancakeInventoryHistory" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawPancakeInventoryHistory" OWNER TO hogikids;

--
-- Name: RawPancakeOrder; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawPancakeOrder" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text,
    "silverOutcome" text,
    "silverProcessedAt" timestamp(3) without time zone,
    "silverNote" text,
    "silverAttempts" integer DEFAULT 0 NOT NULL,
    "silverLastAttemptAt" timestamp(3) without time zone
);


ALTER TABLE app."RawPancakeOrder" OWNER TO hogikids;

--
-- Name: RawPancakeProduct; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawPancakeProduct" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawPancakeProduct" OWNER TO hogikids;

--
-- Name: RawPancakePurchase; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawPancakePurchase" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawPancakePurchase" OWNER TO hogikids;

--
-- Name: RawPancakeReverseOrder; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawPancakeReverseOrder" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawPancakeReverseOrder" OWNER TO hogikids;

--
-- Name: RawPancakeTransaction; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawPancakeTransaction" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawPancakeTransaction" OWNER TO hogikids;

--
-- Name: RawPancakeVariation; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawPancakeVariation" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawPancakeVariation" OWNER TO hogikids;

--
-- Name: RawPancakeWebhookEvent; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawPancakeWebhookEvent" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    payload text NOT NULL,
    "payloadHash" text NOT NULL,
    "receivedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    source text DEFAULT 'webhook'::text NOT NULL,
    "processedAs" text,
    "processedNote" text
);


ALTER TABLE app."RawPancakeWebhookEvent" OWNER TO hogikids;

--
-- Name: RawShopeeWalletTxn; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawShopeeWalletTxn" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawShopeeWalletTxn" OWNER TO hogikids;

--
-- Name: RawTiktokBusinessGmvMaxItem; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawTiktokBusinessGmvMaxItem" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawTiktokBusinessGmvMaxItem" OWNER TO hogikids;

--
-- Name: RawTiktokBusinessInvoice; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawTiktokBusinessInvoice" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawTiktokBusinessInvoice" OWNER TO hogikids;

--
-- Name: RawTiktokBusinessReport; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawTiktokBusinessReport" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawTiktokBusinessReport" OWNER TO hogikids;

--
-- Name: RawTiktokShopAffiliateOrder; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawTiktokShopAffiliateOrder" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawTiktokShopAffiliateOrder" OWNER TO hogikids;

--
-- Name: RawTiktokShopAnalyticsLive; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawTiktokShopAnalyticsLive" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawTiktokShopAnalyticsLive" OWNER TO hogikids;

--
-- Name: RawTiktokShopAnalyticsProduct; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawTiktokShopAnalyticsProduct" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawTiktokShopAnalyticsProduct" OWNER TO hogikids;

--
-- Name: RawTiktokShopAnalyticsShop; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawTiktokShopAnalyticsShop" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawTiktokShopAnalyticsShop" OWNER TO hogikids;

--
-- Name: RawTiktokShopAnalyticsVideo; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawTiktokShopAnalyticsVideo" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawTiktokShopAnalyticsVideo" OWNER TO hogikids;

--
-- Name: RawTiktokShopOrder; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawTiktokShopOrder" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawTiktokShopOrder" OWNER TO hogikids;

--
-- Name: RawTiktokShopPayment; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawTiktokShopPayment" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawTiktokShopPayment" OWNER TO hogikids;

--
-- Name: RawTiktokShopStatement; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawTiktokShopStatement" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawTiktokShopStatement" OWNER TO hogikids;

--
-- Name: RawTiktokShopTransaction; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RawTiktokShopTransaction" (
    id text NOT NULL,
    "shopId" text NOT NULL,
    "externalId" text NOT NULL,
    "payloadHash" text NOT NULL,
    payload jsonb NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "syncLogId" text
);


ALTER TABLE app."RawTiktokShopTransaction" OWNER TO hogikids;

--
-- Name: RecurringExpense; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."RecurringExpense" (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    amount integer NOT NULL,
    "dayOfMonth" integer NOT NULL,
    description text NOT NULL,
    "channelId" text,
    active boolean DEFAULT true NOT NULL,
    "activeFrom" timestamp(3) without time zone
);


ALTER TABLE app."RecurringExpense" OWNER TO hogikids;

--
-- Name: Setting; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."Setting" (
    key text NOT NULL,
    value text NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE app."Setting" OWNER TO hogikids;

--
-- Name: SettingN8n; Type: VIEW; Schema: app; Owner: hogikids
--

CREATE VIEW app."SettingN8n" WITH (security_barrier='true') AS
 SELECT "Setting".key,
    "Setting".value
   FROM app."Setting"
  WHERE ("Setting".key = ANY (ARRAY['n8nAppUrl'::text, 'n8nIngestSecret'::text, 'n8nTokenVaultSecret'::text, 'pancakeApiKeyKho'::text, 'pancakeApiKeyShopee'::text, 'pancakeApiKeyTiktok'::text, 'pancakeShopIdKho'::text, 'pancakeShopIdShopee'::text, 'pancakeShopIdTiktok'::text, 'metaAdsAccountId'::text, 'metaAdsManualDays'::text, 'tiktokShopAppKey'::text, 'tiktokShopAppSecret'::text, 'tiktokShopCipher'::text, 'tiktokShopShopId'::text, 'tiktokShopManualDays'::text, 'tiktokShopAnalyticsManualDays'::text, 'tiktokShopAffiliateManualDays'::text, 'tiktokBusinessAppId'::text, 'tiktokBusinessAppSecret'::text, 'tiktokBusinessToken'::text, 'tiktokBusinessManualDays'::text]));


ALTER TABLE app."SettingN8n" OWNER TO hogikids;

--
-- Name: ShopeeSettlement; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."ShopeeSettlement" (
    id text NOT NULL,
    "externalId" text NOT NULL,
    "shopId" text NOT NULL,
    "txnTime" timestamp(3) without time zone NOT NULL,
    type text NOT NULL,
    "orderCode" text,
    amount integer NOT NULL,
    status text NOT NULL,
    "runningBalance" integer NOT NULL,
    raw jsonb,
    "syncedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE app."ShopeeSettlement" OWNER TO hogikids;

--
-- Name: SoDuChotThang; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."SoDuChotThang" (
    id text NOT NULL,
    thang timestamp(3) without time zone NOT NULL,
    "soDuBank" integer NOT NULL,
    "tienMat" integer NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    CONSTRAINT "SoDuChotThang_tienMat_khong_am" CHECK (("tienMat" >= 0))
);


ALTER TABLE app."SoDuChotThang" OWNER TO hogikids;

--
-- Name: SoTietKiem; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."SoTietKiem" (
    id text NOT NULL,
    name text NOT NULL,
    bank text DEFAULT ''::text NOT NULL,
    principal integer NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "termMonths" integer NOT NULL,
    "maturityDate" timestamp(3) without time zone NOT NULL,
    "annualRateBp" integer NOT NULL,
    "loanId" text,
    "closedAt" timestamp(3) without time zone,
    note text DEFAULT ''::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT "SoTietKiem_annualRateBp_khong_am" CHECK (("annualRateBp" >= 0)),
    CONSTRAINT "SoTietKiem_dao_han_sau_ngay_gui" CHECK (("maturityDate" > "startDate")),
    CONSTRAINT "SoTietKiem_principal_duong" CHECK ((principal > 0)),
    CONSTRAINT "SoTietKiem_termMonths_duong" CHECK (("termMonths" >= 1))
);


ALTER TABLE app."SoTietKiem" OWNER TO hogikids;

--
-- Name: SyncLog; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."SyncLog" (
    id text NOT NULL,
    kind app."SyncKind" NOT NULL,
    status app."SyncStatus" DEFAULT 'RUNNING'::app."SyncStatus" NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "finishedAt" timestamp(3) without time zone,
    stats jsonb,
    error text
);


ALTER TABLE app."SyncLog" OWNER TO hogikids;

--
-- Name: ThuNhap; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."ThuNhap" (
    id text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    kind app."ThuNhapKind" NOT NULL,
    amount integer NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "savingsId" text,
    "refId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT "ThuNhap_amount_duong" CHECK ((amount > 0))
);


ALTER TABLE app."ThuNhap" OWNER TO hogikids;

--
-- Name: TiktokAdsSettlement; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."TiktokAdsSettlement" (
    id text NOT NULL,
    "transactionId" text NOT NULL,
    "shopId" text NOT NULL,
    "adjustmentId" text,
    "orderCreateTime" timestamp(3) without time zone NOT NULL,
    "settlementAmount" integer NOT NULL,
    raw jsonb,
    "syncedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE app."TiktokAdsSettlement" OWNER TO hogikids;

--
-- Name: TiktokPayment; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."TiktokPayment" (
    id text NOT NULL,
    "paymentId" text NOT NULL,
    "shopId" text NOT NULL,
    status text NOT NULL,
    "paidTime" timestamp(3) without time zone,
    "settlementValue" integer NOT NULL,
    "amountValue" integer NOT NULL,
    "reserveValue" integer DEFAULT 0 NOT NULL,
    "bankAccount" text,
    raw jsonb,
    "syncedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE app."TiktokPayment" OWNER TO hogikids;

--
-- Name: TiktokSettlement; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."TiktokSettlement" (
    id text NOT NULL,
    "statementId" text NOT NULL,
    "shopId" text NOT NULL,
    "statementTime" timestamp(3) without time zone NOT NULL,
    "paymentTime" timestamp(3) without time zone,
    "paymentStatus" text NOT NULL,
    "paymentId" text,
    "settlementAmount" integer NOT NULL,
    "revenueAmount" integer NOT NULL,
    "feeAmount" integer NOT NULL,
    "adjustmentAmount" integer NOT NULL,
    "netSalesAmount" integer NOT NULL,
    "shippingCostAmount" integer NOT NULL,
    currency text DEFAULT 'VND'::text NOT NULL,
    raw jsonb,
    "syncedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE app."TiktokSettlement" OWNER TO hogikids;

--
-- Name: User; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."User" (
    id text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    "shopName" text DEFAULT 'HogiKids'::text NOT NULL,
    "shopPhone" text,
    "shopLogoPath" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE app."User" OWNER TO hogikids;

--
-- Name: Variant; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app."Variant" (
    id text NOT NULL,
    "pancakeId" text NOT NULL,
    "productId" text NOT NULL,
    sku text NOT NULL,
    label text NOT NULL,
    "sellPrice" integer DEFAULT 0 NOT NULL,
    stock integer DEFAULT 0 NOT NULL,
    "costPrice" integer DEFAULT 0 NOT NULL,
    "lowStockThreshold" integer,
    "syncedAt" timestamp(3) without time zone NOT NULL,
    "stockUpdatedAt" timestamp(3) without time zone
);


ALTER TABLE app."Variant" OWNER TO hogikids;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: app; Owner: hogikids
--

CREATE TABLE app._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE app._prisma_migrations OWNER TO hogikids;

--
-- Data for Name: BanGhiDaXoa; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."BanGhiDaXoa" (id, bang, "banGhiId", nhan, "soTien", ngay, anh, "xoaLuc", "khoiPhucLuc") FROM stdin;
\.


--
-- Data for Name: CashMovement; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."CashMovement" (id, date, kind, amount, description, "createdAt", "loanId", "savingsId") FROM stdin;
\.


--
-- Data for Name: Channel; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."Channel" (id, name, color, "isActive", "platformFeePct", "paymentFeePct", "sortOrder") FROM stdin;
direct	Bán trực tiếp	#6a8fd8	t	0	0	5
\.


--
-- Data for Name: Expense; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."Expense" (id, date, "categoryId", "adsSource", description, "channelId", amount, source, "refId", "recurringId", "createdAt", "recurringMonth") FROM stdin;
\.


--
-- Data for Name: ExpenseCategory; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."ExpenseCategory" (id, name, "isSystem", "isHidden") FROM stdin;
interest	Lãi vay	t	f
\.


--
-- Data for Name: Loan; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."Loan" (id, name, lender, "duNoMoSo", "startDate", "annualRateBp", "termMonths", "firstDueDate", "lastDueHandled", "closedAt", note, "createdAt", kind, "laiCoDinhMoiKy", "tienGuiBatBuocMoiKy") FROM stdin;
\.


--
-- Data for Name: N8nWorkflowBackup; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."N8nWorkflowBackup" (id, name, payload, "createdAt") FROM stdin;
\.


--
-- Data for Name: Order; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."Order" (id, "pancakeId", code, "channelId", status, "orderedAt", "customerName", "itemsTotal", "shipFeeCustomer", discount, "platformFeeEst", "syncedAt", raw, "returnedFee", "statusChangedAt", "rawFetchedAt", "backfilledFromMirror", "paidAtShop") FROM stdin;
FX-order-1	FX-don-1	FX-DON-1	direct	COMPLETED	2026-09-01 10:00:00	\N	100000	0	0	0	2026-09-01 10:05:00	\N	0	\N	\N	f	0
FX-order-2	FX-don-2	FX-DON-2	direct	CANCELLED	2026-09-02 11:00:00	\N	50000	0	0	0	2026-09-02 11:05:00	\N	0	\N	\N	f	0
\.


--
-- Data for Name: OrderItem; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."OrderItem" (id, "orderId", "variantId", sku, "productName", quantity, "unitPrice", "lineDiscount") FROM stdin;
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."Product" (id, "pancakeId", name, code, "categoryName", "imageUrl", status, "syncedAt") FROM stdin;
\.


--
-- Data for Name: RawMetaAdsReport; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawMetaAdsReport" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawPancakeCustomer; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawPancakeCustomer" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawPancakeInventoryHistory; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawPancakeInventoryHistory" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawPancakeOrder; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawPancakeOrder" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId", "silverOutcome", "silverProcessedAt", "silverNote", "silverAttempts", "silverLastAttemptAt") FROM stdin;
\.


--
-- Data for Name: RawPancakeProduct; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawPancakeProduct" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawPancakePurchase; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawPancakePurchase" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawPancakeReverseOrder; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawPancakeReverseOrder" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawPancakeTransaction; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawPancakeTransaction" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawPancakeVariation; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawPancakeVariation" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawPancakeWebhookEvent; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawPancakeWebhookEvent" (id, "shopId", payload, "payloadHash", "receivedAt", source, "processedAs", "processedNote") FROM stdin;
\.


--
-- Data for Name: RawShopeeWalletTxn; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawShopeeWalletTxn" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawTiktokBusinessGmvMaxItem; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawTiktokBusinessGmvMaxItem" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawTiktokBusinessInvoice; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawTiktokBusinessInvoice" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawTiktokBusinessReport; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawTiktokBusinessReport" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawTiktokShopAffiliateOrder; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawTiktokShopAffiliateOrder" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawTiktokShopAnalyticsLive; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawTiktokShopAnalyticsLive" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawTiktokShopAnalyticsProduct; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawTiktokShopAnalyticsProduct" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawTiktokShopAnalyticsShop; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawTiktokShopAnalyticsShop" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawTiktokShopAnalyticsVideo; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawTiktokShopAnalyticsVideo" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawTiktokShopOrder; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawTiktokShopOrder" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawTiktokShopPayment; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawTiktokShopPayment" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawTiktokShopStatement; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawTiktokShopStatement" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RawTiktokShopTransaction; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RawTiktokShopTransaction" (id, "shopId", "externalId", "payloadHash", payload, "fetchedAt", "syncLogId") FROM stdin;
\.


--
-- Data for Name: RecurringExpense; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."RecurringExpense" (id, "categoryId", amount, "dayOfMonth", description, "channelId", active, "activeFrom") FROM stdin;
\.


--
-- Data for Name: Setting; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."Setting" (key, value, "updatedAt") FROM stdin;
sessionEpoch	1727000000000	2026-09-30 23:15:20.444
\.


--
-- Data for Name: ShopeeSettlement; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."ShopeeSettlement" (id, "externalId", "shopId", "txnTime", type, "orderCode", amount, status, "runningBalance", raw, "syncedAt") FROM stdin;
\.


--
-- Data for Name: SoDuChotThang; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."SoDuChotThang" (id, thang, "soDuBank", "tienMat", note, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: SoTietKiem; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."SoTietKiem" (id, name, bank, principal, "startDate", "termMonths", "maturityDate", "annualRateBp", "loanId", "closedAt", note, "createdAt") FROM stdin;
\.


--
-- Data for Name: SyncLog; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."SyncLog" (id, kind, status, "startedAt", "finishedAt", stats, error) FROM stdin;
\.


--
-- Data for Name: ThuNhap; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."ThuNhap" (id, date, kind, amount, description, "savingsId", "refId", "createdAt") FROM stdin;
\.


--
-- Data for Name: TiktokAdsSettlement; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."TiktokAdsSettlement" (id, "transactionId", "shopId", "adjustmentId", "orderCreateTime", "settlementAmount", raw, "syncedAt") FROM stdin;
\.


--
-- Data for Name: TiktokPayment; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."TiktokPayment" (id, "paymentId", "shopId", status, "paidTime", "settlementValue", "amountValue", "reserveValue", "bankAccount", raw, "syncedAt") FROM stdin;
\.


--
-- Data for Name: TiktokSettlement; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."TiktokSettlement" (id, "statementId", "shopId", "statementTime", "paymentTime", "paymentStatus", "paymentId", "settlementAmount", "revenueAmount", "feeAmount", "adjustmentAmount", "netSalesAmount", "shippingCostAmount", currency, raw, "syncedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."User" (id, email, "passwordHash", "shopName", "shopPhone", "shopLogoPath", "createdAt") FROM stdin;
FX-user-owner	owner@fixture.test	FX-khong-phai-hash	Shop Fixture	\N	\N	2026-09-01 08:00:00
\.


--
-- Data for Name: Variant; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app."Variant" (id, "pancakeId", "productId", sku, label, "sellPrice", stock, "costPrice", "lowStockThreshold", "syncedAt", "stockUpdatedAt") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: app; Owner: hogikids
--

COPY app._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
4ce0213e-82a6-4231-a5f8-b17b64debe5f	92ef211397935a4befc89dc38ea80d360e519ad6e22677b43a4e415ecc655d87	2026-09-30 23:15:20.390723+07	20260908112129_them_loai_thau_chi_cho_khoan_vay	\N	\N	2026-09-30 23:15:20.389867+07	1
0a1ad6d9-9c9e-4bef-9943-6bf0e3777687	fc420b4a8fa3a80b13e2ed2589b3da278458b145ccd0b643121da6048ed22b88	2026-09-30 23:15:20.320872+07	20260706162602_init	\N	\N	2026-09-30 23:15:20.306123+07	1
62c86cf7-dac3-4b72-8436-b3a6400f62ef	cccec83bfc2be0b47e0362135dce85c53848c25cf7952a726d6c2756ca981ffa	2026-09-30 23:15:20.361359+07	20260725071943_them_cot_updated_at_cho_setting	\N	\N	2026-09-30 23:15:20.3591+07	1
8d2960c3-8fd0-4aaf-969d-861f3f4efe51	c34abe1284ac8ae275dc07b82378c11fc526eebb1eac3b9d82d4f14266b6cf84	2026-09-30 23:15:20.322115+07	20260707091256_add_order_item_line_discount	\N	\N	2026-09-30 23:15:20.321186+07	1
2b129f35-d925-4d79-884e-56a536342ef7	7c01a9f5e197e49ef69b1453e7dfc74d2f4c0aade8f34fff4052fecf01e97a97	2026-09-30 23:15:20.333571+07	20260713071412_bronze_raw_layer	\N	\N	2026-09-30 23:15:20.322433+07	1
8bba8c7b-6bee-4f1f-804b-94b2fa0a8111	0035011b9e24b002474e94b51611176413a9706bd173495110e735fa53464ea7	2026-09-30 23:15:20.370231+07	20260811140000_dem_luot_thu_lai_cho_don_bronze	\N	\N	2026-09-30 23:15:20.369591+07	1
b5a57c6d-3aff-4843-a67a-fb545f3eaa8a	e978afb68b20b90886435a310083a7bd7757a502f4f8551ef369e849bc1392a1	2026-09-30 23:15:20.339893+07	20260714074119_bronze_tiktok_shop	\N	\N	2026-09-30 23:15:20.333857+07	1
c659d8c4-bef7-434f-bf58-9df753815e69	9f4f3d0f70755e213d5c9e0408b169f994ae73b04a65bde59133aad183f0806f	2026-09-30 23:15:20.363582+07	20260726164500_them_bang_hung_webhook_pancake	\N	\N	2026-09-30 23:15:20.361583+07	1
ed193076-60b1-4786-a51f-ef39400eee33	6abdc08ec8374bdaa04674dc763373e79ca9a624a70d6c8f12ffbec631f2e653	2026-09-30 23:15:20.340785+07	20260714152000_sync_kind_tiktok_shop	\N	\N	2026-09-30 23:15:20.340129+07	1
f2097bb7-b4f1-4fb8-a1cc-4d44b1c7efdb	38e44a6610376e69352e62decda5e391717ee4e03790b0353262186bd789f26b	2026-09-30 23:15:20.342351+07	20260714170000_rename_raw_tiktok_shop	\N	\N	2026-09-30 23:15:20.341027+07	1
28aa71f6-feca-4438-b3cf-103b64e638b6	987fbbab23b77ad51bad816befd05e81923b73c3b101aa7958b9f0bb83eb8855	2026-09-30 23:15:20.344726+07	20260714174500_bronze_tiktok_business	\N	\N	2026-09-30 23:15:20.342575+07	1
1eae2ee6-04f1-499a-b611-18132f2a430c	afa1e0c64f820ac5e64172df11ada8a0e5c2157530421c0fb1e91a93e37fdd79	2026-09-30 23:15:20.364403+07	20260727074500_them_cot_xu_ly_cho_webhook_event	\N	\N	2026-09-30 23:15:20.363788+07	1
daaf83fa-0bf9-4dea-8e69-f65744d8b46e	09195fde87b4f2f834e40ced9d1cd5aec1056fea9931eb060799772e1d343ac3	2026-09-30 23:15:20.347032+07	20260714180000_bronze_tiktok_business_invoice	\N	\N	2026-09-30 23:15:20.344938+07	1
d525ad49-dd63-4a60-b921-f1ff3e379112	36c272abd7c015113714d41b35e29436e8ddef0ac15b98f59a8c4283ef6b036d	2026-09-30 23:15:20.349029+07	20260714200000_bronze_meta_ads	\N	\N	2026-09-30 23:15:20.347235+07	1
c7ff13b9-e2e9-4126-a45f-c8791b57849d	7e86d4019b24b1059eb80be86d6cd3f7699d8a89dc09abbd29567f8daf0d0d77	2026-09-30 23:15:20.384684+07	20260828110000_bronze_tiktok_affiliate_order	\N	\N	2026-09-30 23:15:20.382614+07	1
bf974588-ba2d-4a26-bf88-f43e303a73ff	8ee61d092a33882ee68752f9adec782758f7c18a85a617d89f7d14b25c400d4e	2026-09-30 23:15:20.35376+07	20260719200000_tiktok_settlement_silver	\N	\N	2026-09-30 23:15:20.34925+07	1
e176fbfa-6c18-4434-9bcf-3a85b95ba16e	8cfe971d12bd6735f59afa58cac68aac794053639ed8e3fe0dbb0ae453df758c	2026-09-30 23:15:20.365423+07	20260727110000_ton_kho_realtime_tu_webhook	\N	\N	2026-09-30 23:15:20.364642+07	1
0b8adb53-f056-404d-9768-da75692e374e	dc92805644e2e82006b6a3e3b39080d2ac230c82b22308b7ced06b8419428c28	2026-09-30 23:15:20.357193+07	20260720002442_shopee_wallet	\N	\N	2026-09-30 23:15:20.354071+07	1
2257c034-6111-4236-9006-cf323b37fd73	d4daf9d69be2f5ab920eb9159b724f2c12f20205dbf126178bec801108636819	2026-09-30 23:15:20.35807+07	20260721073147_add_order_returned_fee	\N	\N	2026-09-30 23:15:20.357397+07	1
7fb5c86b-2c76-47e5-bdbf-50094c099fc2	218f116a8c11adc24222818eb9756dfecabba3ef787dd34a2b956bd37062a2aa	2026-09-30 23:15:20.371202+07	20260821210000_seed_shop_id_pancake_theo_dieu_kien	\N	\N	2026-09-30 23:15:20.370437+07	1
0c08a12b-18d4-4ad4-a4db-5369b473f9b7	9fa308fa8fbb11d3affbdba7fdb1f9be842a9f3868fd60a482faee754fd1ad24	2026-09-30 23:15:20.358873+07	20260722084658_add_order_status_changed_at	\N	\N	2026-09-30 23:15:20.358284+07	1
e867b541-5c4c-4479-bda3-f5ed8d0612b4	adcb6597c8ea45e5df7a3d0c47787dded8522cd6581524288e73cd75ba3b7009	2026-09-30 23:15:20.366395+07	20260729170000_them_moc_nguon_cho_don	\N	\N	2026-09-30 23:15:20.365626+07	1
7bb23d63-6313-4c1a-bf5b-53fdb099257c	c2f877aca24f4459fdd8e4976c2e2d68341debbd98f97bd6bba314ac09bde6be	2026-09-30 23:15:20.367398+07	20260730120000_khoa_trung_ten_danh_muc_chi_phi	\N	\N	2026-09-30 23:15:20.366591+07	1
fc6e5170-ebea-424f-bb10-b5781502697d	c28a3e01023b58b16447a49c84e8e42d130172c4d882d8d75b956e1b033ba70f	2026-09-30 23:15:20.368405+07	20260805170000_danh_dau_don_bu_tu_ban_sao_kho	\N	\N	2026-09-30 23:15:20.367604+07	1
ae0efa99-8a4a-4cfb-bbc0-4644b7572117	80ca7c6a43838908e1d29fbe6f283057c36bf21fdb64a76c432de14f70317c46	2026-09-30 23:15:20.373612+07	20260821224500_view_setting_n8n_va_bang_backup_workflow	\N	\N	2026-09-30 23:15:20.371425+07	1
fdd668e7-ee19-41b4-90dd-3b130ed699c9	014eb177a4e1f7802805f07e27fe46dbaf5a18b356fc61d4d90cbbc22f3ca836	2026-09-30 23:15:20.369381+07	20260811110000_dau_ket_cuc_silver_cho_don_bronze	\N	\N	2026-09-30 23:15:20.368623+07	1
db865caf-9cf5-42ca-8716-a2d7dea96c79	e59503d075c6fb1e97795ae9ea4a10224ec5e8263add90ca8f056a87cf7d26df	2026-09-30 23:15:20.374416+07	20260822011500_setting_n8n_view_security_barrier	\N	\N	2026-09-30 23:15:20.373805+07	1
a7723fd0-6cf7-4ca6-a9fc-632cbf7147f6	9c37ff4988072f6e86dd8a482e76028e62e8372c0c49ccde742930cff0279cf3	2026-09-30 23:15:20.386621+07	20260902130946_them_bang_cash_movement	\N	\N	2026-09-30 23:15:20.38488+07	1
561001dc-93eb-4722-8916-cc5d60623d07	84c7e4e232f9e5b9496c9c4c3a3fe908b49e3c374c7c3bd2e9fc780c50e453f6	2026-09-30 23:15:20.382395+07	20260825120000_bronze_tiktok_analytics_va_gmvmax_item	\N	\N	2026-09-30 23:15:20.37467+07	1
09468c2a-d519-402e-8c97-0b1dbc0f615b	20daf420d9f1d00d9642652a12b7ceda59eb7c4f12870491cca566ca96d9d360	2026-09-30 23:15:20.389667+07	20260907101150_them_khoan_vay_va_danh_muc_lai_vay	\N	\N	2026-09-30 23:15:20.386993+07	1
6eaf2db9-7eaf-4b3b-ad77-e66259e14f73	743008c8247f9185a1698fb0ec487b3b44c64066f7d7ab1c2b35074bc7469140	2026-09-30 23:15:20.393751+07	20260916044605_them_loai_dong_tien_tiet_kiem	\N	\N	2026-09-30 23:15:20.393157+07	1
76728d10-517c-4e98-93e5-fbe4cc157486	5b3cce61550e316f0129d2347bdd1c88001423c8d785fed9ac0b45bb263d1435	2026-09-30 23:15:20.391758+07	20260910101500_them_loai_vay_goc_cuoi_ky	\N	\N	2026-09-30 23:15:20.390922+07	1
675dec84-c723-42b0-85cb-843607bb1f4e	2c02ef3c14fe638431d916a13520f42b1870d4945ceb5fb1d6d303d1242ee7b9	2026-09-30 23:15:20.392934+07	20260910101600_rang_buoc_vay_goc_cuoi_ky	\N	\N	2026-09-30 23:15:20.392004+07	1
323c8957-8356-4c8e-9e2b-98a321babc1b	23615cbe8cc6ba840bb34c4f31014148a670188ad4f2a3c0e690d2cfa1b1a6fc	2026-09-30 23:15:20.399369+07	20260916044938_them_bang_so_tiet_kiem_va_thu_nhap	\N	\N	2026-09-30 23:15:20.393999+07	1
a230473d-11e0-4150-ba16-26364a833ad6	91b0f0dc4488917ec221958c70acf6baef2908a06f601bf72eb485dfc447618a	2026-09-30 23:15:20.401802+07	20260917110000_them_bang_thung_rac	\N	\N	2026-09-30 23:15:20.399611+07	1
3a5323d0-e7e3-4cd5-943f-32c0815c1ca4	b87d38b731f8462fc3fed00f67bcb6b8e6d326903a25901e03be1177d6855efb	2026-09-30 23:15:20.403037+07	20260921130000_setting_n8n_view_allowlist	\N	\N	2026-09-30 23:15:20.402063+07	1
4b8e32d3-4f02-4ff4-94d5-c6ad3aa711b1	fea87b3d63d82fb4e154d0275951c801c170efaed7290168fa7b4f0db2a868d4	2026-09-30 23:15:20.404061+07	20260921230500_ket_cuc_ping_thu_cho_webhook	\N	\N	2026-09-30 23:15:20.403387+07	1
97506b0e-89ee-4bb6-ac3c-41834722a6b0	6fb8a096916f45075fe552452a6d42bcac72bdb6ff1de99e2d48e08ed2a2acd9	2026-09-30 23:15:20.406198+07	20260923143000_them_bang_so_du_chot_thang	\N	\N	2026-09-30 23:15:20.404339+07	1
517fcf62-80bf-4699-8848-1428501e5d95	3dc4eaaef0b3d5185ecaa97610e60c9633f84875eb23107f695faf20304c6052	2026-09-30 23:15:20.407523+07	20260923230000_kenh_ban_truc_tiep	\N	\N	2026-09-30 23:15:20.40641+07	1
458bcc62-e440-445b-ae22-2b0c9a3bab6d	9657a93a5ff2ede11c46093ba0ff960162ded589e287af42eceee25cf6174304	2026-09-30 23:15:20.408345+07	20260925194500_them_moc_active_from_khoan_chi_dinh_ky	\N	\N	2026-09-30 23:15:20.407731+07	1
3287c726-bd82-4794-8417-5b296c8abedc	b47d112d20b437954842908af6619322925122c4ba893e5b9e1ff9f8fdae24aa	2026-09-30 23:15:20.409939+07	20260928160000_mot_dong_dinh_ky_moi_thang_rang_buoc_duy_nhat	\N	\N	2026-09-30 23:15:20.408576+07	1
\.


--
-- Name: BanGhiDaXoa BanGhiDaXoa_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."BanGhiDaXoa"
    ADD CONSTRAINT "BanGhiDaXoa_pkey" PRIMARY KEY (id);


--
-- Name: CashMovement CashMovement_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."CashMovement"
    ADD CONSTRAINT "CashMovement_pkey" PRIMARY KEY (id);


--
-- Name: Channel Channel_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."Channel"
    ADD CONSTRAINT "Channel_pkey" PRIMARY KEY (id);


--
-- Name: ExpenseCategory ExpenseCategory_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."ExpenseCategory"
    ADD CONSTRAINT "ExpenseCategory_pkey" PRIMARY KEY (id);


--
-- Name: Expense Expense_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."Expense"
    ADD CONSTRAINT "Expense_pkey" PRIMARY KEY (id);


--
-- Name: Loan Loan_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."Loan"
    ADD CONSTRAINT "Loan_pkey" PRIMARY KEY (id);


--
-- Name: N8nWorkflowBackup N8nWorkflowBackup_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."N8nWorkflowBackup"
    ADD CONSTRAINT "N8nWorkflowBackup_pkey" PRIMARY KEY (id);


--
-- Name: OrderItem OrderItem_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."OrderItem"
    ADD CONSTRAINT "OrderItem_pkey" PRIMARY KEY (id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: RawMetaAdsReport RawMetaAdsReport_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawMetaAdsReport"
    ADD CONSTRAINT "RawMetaAdsReport_pkey" PRIMARY KEY (id);


--
-- Name: RawPancakeCustomer RawPancakeCustomer_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawPancakeCustomer"
    ADD CONSTRAINT "RawPancakeCustomer_pkey" PRIMARY KEY (id);


--
-- Name: RawPancakeInventoryHistory RawPancakeInventoryHistory_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawPancakeInventoryHistory"
    ADD CONSTRAINT "RawPancakeInventoryHistory_pkey" PRIMARY KEY (id);


--
-- Name: RawPancakeOrder RawPancakeOrder_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawPancakeOrder"
    ADD CONSTRAINT "RawPancakeOrder_pkey" PRIMARY KEY (id);


--
-- Name: RawPancakeProduct RawPancakeProduct_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawPancakeProduct"
    ADD CONSTRAINT "RawPancakeProduct_pkey" PRIMARY KEY (id);


--
-- Name: RawPancakePurchase RawPancakePurchase_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawPancakePurchase"
    ADD CONSTRAINT "RawPancakePurchase_pkey" PRIMARY KEY (id);


--
-- Name: RawPancakeReverseOrder RawPancakeReverseOrder_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawPancakeReverseOrder"
    ADD CONSTRAINT "RawPancakeReverseOrder_pkey" PRIMARY KEY (id);


--
-- Name: RawPancakeTransaction RawPancakeTransaction_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawPancakeTransaction"
    ADD CONSTRAINT "RawPancakeTransaction_pkey" PRIMARY KEY (id);


--
-- Name: RawPancakeVariation RawPancakeVariation_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawPancakeVariation"
    ADD CONSTRAINT "RawPancakeVariation_pkey" PRIMARY KEY (id);


--
-- Name: RawPancakeWebhookEvent RawPancakeWebhookEvent_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawPancakeWebhookEvent"
    ADD CONSTRAINT "RawPancakeWebhookEvent_pkey" PRIMARY KEY (id);


--
-- Name: RawShopeeWalletTxn RawShopeeWalletTxn_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawShopeeWalletTxn"
    ADD CONSTRAINT "RawShopeeWalletTxn_pkey" PRIMARY KEY (id);


--
-- Name: RawTiktokBusinessGmvMaxItem RawTiktokBusinessGmvMaxItem_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawTiktokBusinessGmvMaxItem"
    ADD CONSTRAINT "RawTiktokBusinessGmvMaxItem_pkey" PRIMARY KEY (id);


--
-- Name: RawTiktokBusinessInvoice RawTiktokBusinessInvoice_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawTiktokBusinessInvoice"
    ADD CONSTRAINT "RawTiktokBusinessInvoice_pkey" PRIMARY KEY (id);


--
-- Name: RawTiktokBusinessReport RawTiktokBusinessReport_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawTiktokBusinessReport"
    ADD CONSTRAINT "RawTiktokBusinessReport_pkey" PRIMARY KEY (id);


--
-- Name: RawTiktokShopAffiliateOrder RawTiktokShopAffiliateOrder_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawTiktokShopAffiliateOrder"
    ADD CONSTRAINT "RawTiktokShopAffiliateOrder_pkey" PRIMARY KEY (id);


--
-- Name: RawTiktokShopAnalyticsLive RawTiktokShopAnalyticsLive_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawTiktokShopAnalyticsLive"
    ADD CONSTRAINT "RawTiktokShopAnalyticsLive_pkey" PRIMARY KEY (id);


--
-- Name: RawTiktokShopAnalyticsProduct RawTiktokShopAnalyticsProduct_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawTiktokShopAnalyticsProduct"
    ADD CONSTRAINT "RawTiktokShopAnalyticsProduct_pkey" PRIMARY KEY (id);


--
-- Name: RawTiktokShopAnalyticsShop RawTiktokShopAnalyticsShop_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawTiktokShopAnalyticsShop"
    ADD CONSTRAINT "RawTiktokShopAnalyticsShop_pkey" PRIMARY KEY (id);


--
-- Name: RawTiktokShopAnalyticsVideo RawTiktokShopAnalyticsVideo_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawTiktokShopAnalyticsVideo"
    ADD CONSTRAINT "RawTiktokShopAnalyticsVideo_pkey" PRIMARY KEY (id);


--
-- Name: RawTiktokShopOrder RawTiktokShopOrder_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawTiktokShopOrder"
    ADD CONSTRAINT "RawTiktokShopOrder_pkey" PRIMARY KEY (id);


--
-- Name: RawTiktokShopPayment RawTiktokShopPayment_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawTiktokShopPayment"
    ADD CONSTRAINT "RawTiktokShopPayment_pkey" PRIMARY KEY (id);


--
-- Name: RawTiktokShopStatement RawTiktokShopStatement_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawTiktokShopStatement"
    ADD CONSTRAINT "RawTiktokShopStatement_pkey" PRIMARY KEY (id);


--
-- Name: RawTiktokShopTransaction RawTiktokShopTransaction_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RawTiktokShopTransaction"
    ADD CONSTRAINT "RawTiktokShopTransaction_pkey" PRIMARY KEY (id);


--
-- Name: RecurringExpense RecurringExpense_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."RecurringExpense"
    ADD CONSTRAINT "RecurringExpense_pkey" PRIMARY KEY (id);


--
-- Name: Setting Setting_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."Setting"
    ADD CONSTRAINT "Setting_pkey" PRIMARY KEY (key);


--
-- Name: ShopeeSettlement ShopeeSettlement_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."ShopeeSettlement"
    ADD CONSTRAINT "ShopeeSettlement_pkey" PRIMARY KEY (id);


--
-- Name: SoDuChotThang SoDuChotThang_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."SoDuChotThang"
    ADD CONSTRAINT "SoDuChotThang_pkey" PRIMARY KEY (id);


--
-- Name: SoTietKiem SoTietKiem_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."SoTietKiem"
    ADD CONSTRAINT "SoTietKiem_pkey" PRIMARY KEY (id);


--
-- Name: SyncLog SyncLog_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."SyncLog"
    ADD CONSTRAINT "SyncLog_pkey" PRIMARY KEY (id);


--
-- Name: ThuNhap ThuNhap_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."ThuNhap"
    ADD CONSTRAINT "ThuNhap_pkey" PRIMARY KEY (id);


--
-- Name: TiktokAdsSettlement TiktokAdsSettlement_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."TiktokAdsSettlement"
    ADD CONSTRAINT "TiktokAdsSettlement_pkey" PRIMARY KEY (id);


--
-- Name: TiktokPayment TiktokPayment_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."TiktokPayment"
    ADD CONSTRAINT "TiktokPayment_pkey" PRIMARY KEY (id);


--
-- Name: TiktokSettlement TiktokSettlement_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."TiktokSettlement"
    ADD CONSTRAINT "TiktokSettlement_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Variant Variant_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."Variant"
    ADD CONSTRAINT "Variant_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: BanGhiDaXoa_bang_banGhiId_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "BanGhiDaXoa_bang_banGhiId_idx" ON app."BanGhiDaXoa" USING btree (bang, "banGhiId");


--
-- Name: BanGhiDaXoa_xoaLuc_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "BanGhiDaXoa_xoaLuc_idx" ON app."BanGhiDaXoa" USING btree ("xoaLuc");


--
-- Name: CashMovement_date_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "CashMovement_date_idx" ON app."CashMovement" USING btree (date);


--
-- Name: CashMovement_loanId_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "CashMovement_loanId_idx" ON app."CashMovement" USING btree ("loanId");


--
-- Name: CashMovement_savingsId_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "CashMovement_savingsId_idx" ON app."CashMovement" USING btree ("savingsId");


--
-- Name: ExpenseCategory_name_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "ExpenseCategory_name_key" ON app."ExpenseCategory" USING btree (name);


--
-- Name: Expense_categoryId_date_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "Expense_categoryId_date_idx" ON app."Expense" USING btree ("categoryId", date);


--
-- Name: Expense_date_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "Expense_date_idx" ON app."Expense" USING btree (date);


--
-- Name: Expense_recurringId_recurringMonth_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "Expense_recurringId_recurringMonth_key" ON app."Expense" USING btree ("recurringId", "recurringMonth");


--
-- Name: Expense_refId_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "Expense_refId_key" ON app."Expense" USING btree ("refId");


--
-- Name: N8nWorkflowBackup_name_createdAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "N8nWorkflowBackup_name_createdAt_idx" ON app."N8nWorkflowBackup" USING btree (name, "createdAt");


--
-- Name: OrderItem_orderId_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "OrderItem_orderId_idx" ON app."OrderItem" USING btree ("orderId");


--
-- Name: OrderItem_variantId_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "OrderItem_variantId_idx" ON app."OrderItem" USING btree ("variantId");


--
-- Name: Order_channelId_orderedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "Order_channelId_orderedAt_idx" ON app."Order" USING btree ("channelId", "orderedAt");


--
-- Name: Order_orderedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "Order_orderedAt_idx" ON app."Order" USING btree ("orderedAt");


--
-- Name: Order_pancakeId_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "Order_pancakeId_key" ON app."Order" USING btree ("pancakeId");


--
-- Name: Order_status_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "Order_status_idx" ON app."Order" USING btree (status);


--
-- Name: Product_pancakeId_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "Product_pancakeId_key" ON app."Product" USING btree ("pancakeId");


--
-- Name: RawMetaAdsReport_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawMetaAdsReport_fetchedAt_idx" ON app."RawMetaAdsReport" USING btree ("fetchedAt");


--
-- Name: RawMetaAdsReport_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawMetaAdsReport_shopId_externalId_fetchedAt_idx" ON app."RawMetaAdsReport" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawMetaAdsReport_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawMetaAdsReport_shopId_externalId_payloadHash_key" ON app."RawMetaAdsReport" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawPancakeCustomer_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakeCustomer_fetchedAt_idx" ON app."RawPancakeCustomer" USING btree ("fetchedAt");


--
-- Name: RawPancakeCustomer_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakeCustomer_shopId_externalId_fetchedAt_idx" ON app."RawPancakeCustomer" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawPancakeCustomer_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawPancakeCustomer_shopId_externalId_payloadHash_key" ON app."RawPancakeCustomer" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawPancakeInventoryHistory_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakeInventoryHistory_fetchedAt_idx" ON app."RawPancakeInventoryHistory" USING btree ("fetchedAt");


--
-- Name: RawPancakeInventoryHistory_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakeInventoryHistory_shopId_externalId_fetchedAt_idx" ON app."RawPancakeInventoryHistory" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawPancakeInventoryHistory_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawPancakeInventoryHistory_shopId_externalId_payloadHash_key" ON app."RawPancakeInventoryHistory" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawPancakeOrder_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakeOrder_fetchedAt_idx" ON app."RawPancakeOrder" USING btree ("fetchedAt");


--
-- Name: RawPancakeOrder_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakeOrder_shopId_externalId_fetchedAt_idx" ON app."RawPancakeOrder" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawPancakeOrder_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawPancakeOrder_shopId_externalId_payloadHash_key" ON app."RawPancakeOrder" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawPancakeProduct_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakeProduct_fetchedAt_idx" ON app."RawPancakeProduct" USING btree ("fetchedAt");


--
-- Name: RawPancakeProduct_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakeProduct_shopId_externalId_fetchedAt_idx" ON app."RawPancakeProduct" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawPancakeProduct_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawPancakeProduct_shopId_externalId_payloadHash_key" ON app."RawPancakeProduct" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawPancakePurchase_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakePurchase_fetchedAt_idx" ON app."RawPancakePurchase" USING btree ("fetchedAt");


--
-- Name: RawPancakePurchase_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakePurchase_shopId_externalId_fetchedAt_idx" ON app."RawPancakePurchase" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawPancakePurchase_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawPancakePurchase_shopId_externalId_payloadHash_key" ON app."RawPancakePurchase" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawPancakeReverseOrder_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakeReverseOrder_fetchedAt_idx" ON app."RawPancakeReverseOrder" USING btree ("fetchedAt");


--
-- Name: RawPancakeReverseOrder_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakeReverseOrder_shopId_externalId_fetchedAt_idx" ON app."RawPancakeReverseOrder" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawPancakeReverseOrder_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawPancakeReverseOrder_shopId_externalId_payloadHash_key" ON app."RawPancakeReverseOrder" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawPancakeTransaction_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakeTransaction_fetchedAt_idx" ON app."RawPancakeTransaction" USING btree ("fetchedAt");


--
-- Name: RawPancakeTransaction_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakeTransaction_shopId_externalId_fetchedAt_idx" ON app."RawPancakeTransaction" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawPancakeTransaction_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawPancakeTransaction_shopId_externalId_payloadHash_key" ON app."RawPancakeTransaction" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawPancakeVariation_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakeVariation_fetchedAt_idx" ON app."RawPancakeVariation" USING btree ("fetchedAt");


--
-- Name: RawPancakeVariation_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakeVariation_shopId_externalId_fetchedAt_idx" ON app."RawPancakeVariation" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawPancakeVariation_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawPancakeVariation_shopId_externalId_payloadHash_key" ON app."RawPancakeVariation" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawPancakeWebhookEvent_receivedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakeWebhookEvent_receivedAt_idx" ON app."RawPancakeWebhookEvent" USING btree ("receivedAt");


--
-- Name: RawPancakeWebhookEvent_shopId_receivedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawPancakeWebhookEvent_shopId_receivedAt_idx" ON app."RawPancakeWebhookEvent" USING btree ("shopId", "receivedAt");


--
-- Name: RawPancakeWebhookEvent_shopId_receivedAt_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawPancakeWebhookEvent_shopId_receivedAt_payloadHash_key" ON app."RawPancakeWebhookEvent" USING btree ("shopId", "receivedAt", "payloadHash");


--
-- Name: RawShopeeWalletTxn_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawShopeeWalletTxn_fetchedAt_idx" ON app."RawShopeeWalletTxn" USING btree ("fetchedAt");


--
-- Name: RawShopeeWalletTxn_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawShopeeWalletTxn_shopId_externalId_fetchedAt_idx" ON app."RawShopeeWalletTxn" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawShopeeWalletTxn_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawShopeeWalletTxn_shopId_externalId_payloadHash_key" ON app."RawShopeeWalletTxn" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawTiktokBusinessGmvMaxItem_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokBusinessGmvMaxItem_fetchedAt_idx" ON app."RawTiktokBusinessGmvMaxItem" USING btree ("fetchedAt");


--
-- Name: RawTiktokBusinessGmvMaxItem_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokBusinessGmvMaxItem_shopId_externalId_fetchedAt_idx" ON app."RawTiktokBusinessGmvMaxItem" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawTiktokBusinessGmvMaxItem_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawTiktokBusinessGmvMaxItem_shopId_externalId_payloadHash_key" ON app."RawTiktokBusinessGmvMaxItem" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawTiktokBusinessInvoice_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokBusinessInvoice_fetchedAt_idx" ON app."RawTiktokBusinessInvoice" USING btree ("fetchedAt");


--
-- Name: RawTiktokBusinessInvoice_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokBusinessInvoice_shopId_externalId_fetchedAt_idx" ON app."RawTiktokBusinessInvoice" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawTiktokBusinessInvoice_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawTiktokBusinessInvoice_shopId_externalId_payloadHash_key" ON app."RawTiktokBusinessInvoice" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawTiktokBusinessReport_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokBusinessReport_fetchedAt_idx" ON app."RawTiktokBusinessReport" USING btree ("fetchedAt");


--
-- Name: RawTiktokBusinessReport_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokBusinessReport_shopId_externalId_fetchedAt_idx" ON app."RawTiktokBusinessReport" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawTiktokBusinessReport_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawTiktokBusinessReport_shopId_externalId_payloadHash_key" ON app."RawTiktokBusinessReport" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawTiktokShopAffiliateOrder_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopAffiliateOrder_fetchedAt_idx" ON app."RawTiktokShopAffiliateOrder" USING btree ("fetchedAt");


--
-- Name: RawTiktokShopAffiliateOrder_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopAffiliateOrder_shopId_externalId_fetchedAt_idx" ON app."RawTiktokShopAffiliateOrder" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawTiktokShopAffiliateOrder_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawTiktokShopAffiliateOrder_shopId_externalId_payloadHash_key" ON app."RawTiktokShopAffiliateOrder" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawTiktokShopAnalyticsLive_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopAnalyticsLive_fetchedAt_idx" ON app."RawTiktokShopAnalyticsLive" USING btree ("fetchedAt");


--
-- Name: RawTiktokShopAnalyticsLive_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopAnalyticsLive_shopId_externalId_fetchedAt_idx" ON app."RawTiktokShopAnalyticsLive" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawTiktokShopAnalyticsLive_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawTiktokShopAnalyticsLive_shopId_externalId_payloadHash_key" ON app."RawTiktokShopAnalyticsLive" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawTiktokShopAnalyticsProduct_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopAnalyticsProduct_fetchedAt_idx" ON app."RawTiktokShopAnalyticsProduct" USING btree ("fetchedAt");


--
-- Name: RawTiktokShopAnalyticsProduct_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopAnalyticsProduct_shopId_externalId_fetchedAt_idx" ON app."RawTiktokShopAnalyticsProduct" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawTiktokShopAnalyticsProduct_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawTiktokShopAnalyticsProduct_shopId_externalId_payloadHash_key" ON app."RawTiktokShopAnalyticsProduct" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawTiktokShopAnalyticsShop_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopAnalyticsShop_fetchedAt_idx" ON app."RawTiktokShopAnalyticsShop" USING btree ("fetchedAt");


--
-- Name: RawTiktokShopAnalyticsShop_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopAnalyticsShop_shopId_externalId_fetchedAt_idx" ON app."RawTiktokShopAnalyticsShop" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawTiktokShopAnalyticsShop_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawTiktokShopAnalyticsShop_shopId_externalId_payloadHash_key" ON app."RawTiktokShopAnalyticsShop" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawTiktokShopAnalyticsVideo_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopAnalyticsVideo_fetchedAt_idx" ON app."RawTiktokShopAnalyticsVideo" USING btree ("fetchedAt");


--
-- Name: RawTiktokShopAnalyticsVideo_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopAnalyticsVideo_shopId_externalId_fetchedAt_idx" ON app."RawTiktokShopAnalyticsVideo" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawTiktokShopAnalyticsVideo_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawTiktokShopAnalyticsVideo_shopId_externalId_payloadHash_key" ON app."RawTiktokShopAnalyticsVideo" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawTiktokShopOrder_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopOrder_fetchedAt_idx" ON app."RawTiktokShopOrder" USING btree ("fetchedAt");


--
-- Name: RawTiktokShopOrder_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopOrder_shopId_externalId_fetchedAt_idx" ON app."RawTiktokShopOrder" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawTiktokShopOrder_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawTiktokShopOrder_shopId_externalId_payloadHash_key" ON app."RawTiktokShopOrder" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawTiktokShopPayment_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopPayment_fetchedAt_idx" ON app."RawTiktokShopPayment" USING btree ("fetchedAt");


--
-- Name: RawTiktokShopPayment_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopPayment_shopId_externalId_fetchedAt_idx" ON app."RawTiktokShopPayment" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawTiktokShopPayment_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawTiktokShopPayment_shopId_externalId_payloadHash_key" ON app."RawTiktokShopPayment" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawTiktokShopStatement_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopStatement_fetchedAt_idx" ON app."RawTiktokShopStatement" USING btree ("fetchedAt");


--
-- Name: RawTiktokShopStatement_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopStatement_shopId_externalId_fetchedAt_idx" ON app."RawTiktokShopStatement" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawTiktokShopStatement_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawTiktokShopStatement_shopId_externalId_payloadHash_key" ON app."RawTiktokShopStatement" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: RawTiktokShopTransaction_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopTransaction_fetchedAt_idx" ON app."RawTiktokShopTransaction" USING btree ("fetchedAt");


--
-- Name: RawTiktokShopTransaction_shopId_externalId_fetchedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "RawTiktokShopTransaction_shopId_externalId_fetchedAt_idx" ON app."RawTiktokShopTransaction" USING btree ("shopId", "externalId", "fetchedAt");


--
-- Name: RawTiktokShopTransaction_shopId_externalId_payloadHash_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "RawTiktokShopTransaction_shopId_externalId_payloadHash_key" ON app."RawTiktokShopTransaction" USING btree ("shopId", "externalId", "payloadHash");


--
-- Name: ShopeeSettlement_externalId_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "ShopeeSettlement_externalId_key" ON app."ShopeeSettlement" USING btree ("externalId");


--
-- Name: ShopeeSettlement_txnTime_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "ShopeeSettlement_txnTime_idx" ON app."ShopeeSettlement" USING btree ("txnTime");


--
-- Name: SoDuChotThang_thang_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "SoDuChotThang_thang_key" ON app."SoDuChotThang" USING btree (thang);


--
-- Name: SoTietKiem_closedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "SoTietKiem_closedAt_idx" ON app."SoTietKiem" USING btree ("closedAt");


--
-- Name: SoTietKiem_maturityDate_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "SoTietKiem_maturityDate_idx" ON app."SoTietKiem" USING btree ("maturityDate");


--
-- Name: SyncLog_kind_startedAt_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "SyncLog_kind_startedAt_idx" ON app."SyncLog" USING btree (kind, "startedAt");


--
-- Name: ThuNhap_date_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "ThuNhap_date_idx" ON app."ThuNhap" USING btree (date);


--
-- Name: ThuNhap_refId_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "ThuNhap_refId_key" ON app."ThuNhap" USING btree ("refId");


--
-- Name: ThuNhap_savingsId_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "ThuNhap_savingsId_idx" ON app."ThuNhap" USING btree ("savingsId");


--
-- Name: TiktokAdsSettlement_orderCreateTime_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "TiktokAdsSettlement_orderCreateTime_idx" ON app."TiktokAdsSettlement" USING btree ("orderCreateTime");


--
-- Name: TiktokAdsSettlement_transactionId_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "TiktokAdsSettlement_transactionId_key" ON app."TiktokAdsSettlement" USING btree ("transactionId");


--
-- Name: TiktokPayment_paidTime_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "TiktokPayment_paidTime_idx" ON app."TiktokPayment" USING btree ("paidTime");


--
-- Name: TiktokPayment_paymentId_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "TiktokPayment_paymentId_key" ON app."TiktokPayment" USING btree ("paymentId");


--
-- Name: TiktokSettlement_statementId_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "TiktokSettlement_statementId_key" ON app."TiktokSettlement" USING btree ("statementId");


--
-- Name: TiktokSettlement_statementTime_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "TiktokSettlement_statementTime_idx" ON app."TiktokSettlement" USING btree ("statementTime");


--
-- Name: User_email_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "User_email_key" ON app."User" USING btree (email);


--
-- Name: Variant_pancakeId_key; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE UNIQUE INDEX "Variant_pancakeId_key" ON app."Variant" USING btree ("pancakeId");


--
-- Name: Variant_sku_idx; Type: INDEX; Schema: app; Owner: hogikids
--

CREATE INDEX "Variant_sku_idx" ON app."Variant" USING btree (sku);


--
-- Name: Setting setting_set_updated_at; Type: TRIGGER; Schema: app; Owner: hogikids
--

CREATE TRIGGER setting_set_updated_at BEFORE UPDATE ON app."Setting" FOR EACH ROW EXECUTE FUNCTION app.set_setting_updated_at();


--
-- Name: CashMovement CashMovement_loanId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."CashMovement"
    ADD CONSTRAINT "CashMovement_loanId_fkey" FOREIGN KEY ("loanId") REFERENCES app."Loan"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CashMovement CashMovement_savingsId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."CashMovement"
    ADD CONSTRAINT "CashMovement_savingsId_fkey" FOREIGN KEY ("savingsId") REFERENCES app."SoTietKiem"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Expense Expense_categoryId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."Expense"
    ADD CONSTRAINT "Expense_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES app."ExpenseCategory"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Expense Expense_channelId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."Expense"
    ADD CONSTRAINT "Expense_channelId_fkey" FOREIGN KEY ("channelId") REFERENCES app."Channel"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: OrderItem OrderItem_orderId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."OrderItem"
    ADD CONSTRAINT "OrderItem_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES app."Order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OrderItem OrderItem_variantId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."OrderItem"
    ADD CONSTRAINT "OrderItem_variantId_fkey" FOREIGN KEY ("variantId") REFERENCES app."Variant"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Order Order_channelId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."Order"
    ADD CONSTRAINT "Order_channelId_fkey" FOREIGN KEY ("channelId") REFERENCES app."Channel"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SoTietKiem SoTietKiem_loanId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."SoTietKiem"
    ADD CONSTRAINT "SoTietKiem_loanId_fkey" FOREIGN KEY ("loanId") REFERENCES app."Loan"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ThuNhap ThuNhap_savingsId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."ThuNhap"
    ADD CONSTRAINT "ThuNhap_savingsId_fkey" FOREIGN KEY ("savingsId") REFERENCES app."SoTietKiem"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Variant Variant_productId_fkey; Type: FK CONSTRAINT; Schema: app; Owner: hogikids
--

ALTER TABLE ONLY app."Variant"
    ADD CONSTRAINT "Variant_productId_fkey" FOREIGN KEY ("productId") REFERENCES app."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict osdljGflvzfZZ7mdHSS4cXQTGrHw0PtFeP8d4stQiNYNNObMSxHpS0Jf1d1daee

